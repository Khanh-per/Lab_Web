# 🌟 Personal Portfolio Website

[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

> 🎨 A stunning 7-page personal portfolio website built for the Web Application Development course (Assignment 1). Showcasing my skills, projects, and blog through modern web technologies.

🔗 **Website URL:** https://[your-github-username].github.io/[your-repo-name]/

## 🗺️ Site Map

The website includes these exciting pages:

### 🏠 Homepage
`/index.html` - Your first impression! Meet a passionate third-year student at HCMIU-VNU.

### 👨‍💼 About Me
`/about.html` - Dive deep into my story, skills, and frontend journey.

### 💼 Projects Gallery
`/projects.html` - Explore my creative works with stunning visuals and detailed descriptions.

### ✍️ Blog Section
`/blog.html` - Read my thoughts and insights on technology and development.

### 📝 Featured Article
`/post-1.html` - Check out "My Top 5 VS Code Extensions" and more!

### 📍 Location
`/location.html` - Find me in the vibrant city via Google Maps.

### 📬 Get in Touch
`/contact.html` - Let's connect through our feature-rich contact form.

## ⭐ Features & Technical Highlights

### 🏗️ Structure
- 7 semantic HTML5 files
- Modern tag usage (`<header>`, `<nav>`, `<main>`, `<footer>`)

### 🖼️ Media
- 5+ optimized images (.webp/.jpg)
- Alt text for accessibility
- Semantic `<figure>/<figcaption>` elements

### 🗺️ Integration
- Embedded Google Maps iframe
- Seamless third-party integration

### 📝 Interactive Forms
- 10+ input types
- Client-side validation
- Enhanced user experience

### 🎨 Styling
- Single CSS file
- CSS Variables for theming
- Dark/Light mode toggle

### 📱 Responsive Design
- Flexbox layout
- Mobile-first approach
- 768px breakpoint

### ♿ Accessibility
- WCAG compliance
- High contrast ratios
- Keyboard navigation
- Semantic heading structure

### 🚀 Performance
- W3C validated
- Optimized assets
- Meta tags optimization
- Custom favicon

## 🚀 Quick Start

```bash
# Clone this fantastic project
git clone [your-repo-URL]

# Navigate to project directory
cd [your-repo-name]

# Open in your favorite browser
# No server required! 🎉
```

## 🌈 Color Scheme

| Element | Light Mode | Dark Mode |
|---------|------------|-----------|
| Background | Gradient light | Gradient dark |
| Text | #2c3e50 | #e2e8f0 |
| Primary | #2BBCE8 | #3CC7F4 |
| Secondary | #1e6cc0 | #2580D8 |

## 📱 Responsive Breakpoints

| Device | Width |
|--------|-------|
| Mobile | < 768px |
| Tablet | ≥ 768px |
| Desktop | ≥ 1024px |

---

<div align="center">

🌟 **Made with passion and modern web technologies** 🌟

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Last Updated](https://img.shields.io/badge/Last%20Updated-October%202025-brightgreen.svg)](https://github.com/[your-username]/[your-repo])

</div>

Open the index.html file in any modern web browser.

Credits

Images: All project and blog images are placeholders from Placehold.co. Profile picture from Figma.

Icons: Icons used in the navigation and contact form are from Font Awesome.

Fonts: Using the 'Inter' font family from Google Fonts.